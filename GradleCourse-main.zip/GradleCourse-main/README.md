# DIO Gradle course
This is the repository of Digital Innovation One Gradle course, that I am the teacher.
You can follow this course for free here: https://www.dio.me/ 

